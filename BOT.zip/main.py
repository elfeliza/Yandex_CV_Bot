from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

import telebot

bot = telebot.TeleBot("6322819748:AAFNIuSrtSz9ZAlnTkl0DK4xRwKuKW5Y7Do")

bot.remove_webhook()
bot.set_webhook("https://d5d3041c13om056df5pq.apigw.yandexcloud.net")

# токен бота
API_TOKEN = '6322819748:AAFNIuSrtSz9ZAlnTkl0DK4xRwKuKW5Y7Do'
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# создание кнопок для первичного выбора дейсвий
urlkb = InlineKeyboardMarkup(row_width=1)
urlButton = InlineKeyboardButton(text='Посмотреть фотографии', callback_data='button1')
urlButton2 = InlineKeyboardButton(text='Послушать истории', callback_data='button2')
urlButton3 = InlineKeyboardButton(text='Узнать об увлечениях', callback_data='button3')
urlkb.add(urlButton, urlButton2, urlButton3)


# сообщение юзеру после запуска бота
@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.answer("Привет, друг! Я Лесной Эльф, личный помощник Элизы. Что ты хочешь о ней узнать?",
                         reply_markup=urlkb)


# кнопки для показа фотографий
photokb = InlineKeyboardMarkup(row_width=1)
photoButton1 = InlineKeyboardButton(text='Молодая Элиза', callback_data='button_photo_1')
photoButton2 = InlineKeyboardButton(text='Старая Элиза', callback_data='button_photo_2')
photokb.add(photoButton1, photoButton2)


# выбор фотографии
@dp.callback_query_handler(lambda c: c.data == 'button1')
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, "Готовь свои нервы. Какую фотографию тебе показать?",
                           reply_markup=photokb)


# показ школьного фото
@dp.callback_query_handler(lambda c: c.data == 'button_photo_1')
async def process_callback_button_photo_1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_photo(callback_query.from_user.id, photo=open("school.png", 'rb'),
                         caption="В школе Элиза организовывала разные мероприятия и любила котиков. Иногда она надевала фиолетовые очки, чтобы ботать матан было не так грустно.")


# показ фото старой Элизы
@dp.callback_query_handler(lambda c: c.data == 'button_photo_2')
async def process_callback_button_photo_2(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_photo(callback_query, photo=open("old.png", 'rb'),
                         caption="Элиза любит ходить в походы, фото в понамке приехало из пещерных городов Крыма. Еще она любит собирать квадрокоптеры и занимается чирлидингом - строит пирамиды из людей!")


# кнопки для рассказа об увлечениях
storykb = InlineKeyboardMarkup(row_width=1)
storyButton1 = InlineKeyboardButton(text='Коротко об Элизе', callback_data='button_story_1')
storyButton2 = InlineKeyboardButton(text='Главное увлечение', callback_data='button_story_2')
storykb.add(storyButton1, storyButton2)


# выбор рассказа про увлечения
@dp.callback_query_handler(lambda c: c.data == 'button3')
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, "Темные моменты биографии я опущу. О чем хочешь узнать?",
                           reply_markup=storykb)


# об Элизе
@dp.callback_query_handler(lambda c: c.data == 'button_story_1')
async def process_callback_button_story_1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id,
                           'Буду краток. Элиза data scientist, она вышла замуж за Python, но еще шикарно делает презентации и часто общается с Figma. Иногда она моделирует машинные двигатели в SolidWorks и делает квадрокоптеры, но иногда ей хочется стать русалкой.')

# о главном увлечении
@dp.callback_query_handler(lambda c: c.data == 'button_story_2')
async def process_callback_button_story_2(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id,
                           "Находить что-то новое. Вечер удался если квантовые вычисления усокрили перемножение матриц, приложение по колонизации Марса придумано, новая поза йоги выучена, а ее брат тихонько грустит над интерпритируемостью Python. Именно по этой причине Элиза за свои 20 лет попробовала примерно *** (очень много). Она обучала роботов компьютерному зрению, чтобы те играли в футбол, сделала свой интернет-магазин арахисовой пасты в 9 классе, прошла 1000 и 1 курс по машинному обучению, чтобы убедиться, что под капотом не магия, а линал, поступила в МФТИ (тоже,видимо, убедиться в чем-то), занялась моделированием пончиков в Blender и нейробиологией и еще много-много всего. На сегодняшний день она работала на позиции Project Manager, тестировщик, Python-разработчик и сейчас Data Science. В целом, кроме Python, Элиза готова рассказывать как поступить в универ мечты, справиться с нервами перед ЕГЭ, как научиться понимать себя и, главное, зачем вообще учиться.")


# кнопки для рассказа историй
voicekb = InlineKeyboardMarkup(row_width=1)
voiceButton1 = InlineKeyboardButton(text='Чем отличается SQL от NoSQL', callback_data='button_voice_1')
voiceButton2 = InlineKeyboardButton(text='Что такое GPT?', callback_data='button_voice_2')
voiceButton3 = InlineKeyboardButton(text="История первое любви", callback_data='button_voice_3')

voicekb.add(voiceButton1, voiceButton2, voiceButton3)


# выбор истории
@dp.callback_query_handler(lambda c: c.data == 'button2')
async def process_callback_button1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, "Приготовься, будет интересно. Что бы ты хотел послушать?",
                           reply_markup=voicekb)


# показ школьного фото
@dp.callback_query_handler(lambda c: c.data == 'button_voice_1')
async def process_callback_button_photo_1(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_audio(callback_query.from_user.id, audio=open("Об SQL и NoSQL.m4a", 'rb'))

# показ школьного фото
@dp.callback_query_handler(lambda c: c.data == 'button_voice_2')
async def process_callback_button_photo_2(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_audio(callback_query.from_user.id, audio=open("GPT и AI.m4a", 'rb'))

# показ школьного фото
@dp.callback_query_handler(lambda c: c.data == 'button_voice_3')
async def process_callback_button_photo_3(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_audio(callback_query.from_user.id, audio=open("История первой любви.m4a", 'rb'))


############################################################################


#AQVNxrUgA4UubnuuBLt0xqhNEFxMekwtTHE-Bvv3
import pathlib

@dp.message_handler(content_types='voice')
async def voice_message(message: types.Message):
    if(message.voice):
        await bot.send_message(message.chat.id, "This is voice")


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
